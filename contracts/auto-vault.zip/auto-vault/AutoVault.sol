// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";

import "../v4/V4Deployments8453.sol";
import "./interfaces/IAutoVault.sol";
import "./interfaces/IAutoStrategy.sol";
import "./interfaces/IAutoLiquidToken.sol";

interface IWETH is IERC20 {
    function deposit() external payable;
    function withdraw(uint256) external;
}

/// @title AutoVault
/// @notice Multi-asset deposit vault (ETH/WETH/ASSET) with WETH-notional shares; withdraw as WETH or ASSET.
/// @dev Exposes liquid-token `balanceOf` / `totalSupply` so strategy reads share state via the vault.
contract AutoVault is Ownable, ReentrancyGuard, Pausable, IAutoVault {
    using SafeERC20 for IERC20;

    IWETH public immutable weth;
    IAutoStrategy public strategy;
    IAutoLiquidToken public liquidToken;
    IERC20 public asset;
    address public factory;
    bool public bootstrapped;
    bool public neutral;

    event Deposit(address indexed user, uint256 wethNotional, uint256 shares);
    event Withdraw(address indexed user, uint256 shares, bool asAsset, uint256 outAmount);
    event NeutralEntered(uint256 poolValue);
    event NeutralExited();
    event PoolValueSnapshotRecorded(uint256 valueWeth, uint256 uniswapFeesCollected, uint64 timestamp);

    /// @dev Index `0` is oldest; newest is `poolValueSnapshots.length - 1`.
    PoolValueSnapshot[] private _poolValueSnapshots;

    error Unauthorized();
    error ZeroAddress();
    error ZeroValue();
    error AlreadyBootstrapped();
    error NotBootstrapped();

    /// @dev Implementation-only; clones skip constructors — `bootstrap` records the factory.
    constructor() Ownable(msg.sender) {
        weth = IWETH(V4Deployments8453.WETH);
    }

    modifier onlyAutoKeeper() {
        if (msg.sender != strategy.keeper()) revert Unauthorized();
        _;
    }

    function bootstrap(address owner_, address strategy_, address liquidToken_, address asset_) external {
        if (bootstrapped) revert AlreadyBootstrapped();
        if (owner_ == address(0) || strategy_ == address(0) || liquidToken_ == address(0) || asset_ == address(0)) {
            revert ZeroAddress();
        }
        factory = msg.sender;
        strategy = IAutoStrategy(strategy_);
        liquidToken = IAutoLiquidToken(liquidToken_);
        asset = IERC20(asset_);
        bootstrapped = true;
        _transferOwnership(owner_);
    }

    /// @notice Record strategy NAV + cumulative `UniswapFeesCollected` (as currently stored on strategy).
    function recordPoolValueSnapshot() external override onlyAutoKeeper {
        if (!bootstrapped) revert NotBootstrapped();
        uint256 pv = strategy.poolValue();
        uint256 fees = strategy.UniswapFeesCollected();
        _poolValueSnapshots.push(
            PoolValueSnapshot({
                valueWeth: pv,
                uniswapFeesCollected: fees,
                timestamp: uint64(block.timestamp)
            })
        );
        emit PoolValueSnapshotRecorded(pv, fees, uint64(block.timestamp));
    }

    function getPoolValueSnapshotCount() external view override returns (uint256) {
        return _poolValueSnapshots.length;
    }

    function poolValueSnapshots(uint256 index)
        external
        view
        override
        returns (uint256 valueWeth, uint256 uniswapFeesCollected, uint64 timestamp)
    {
        PoolValueSnapshot storage s = _poolValueSnapshots[index];
        return (s.valueWeth, s.uniswapFeesCollected, s.timestamp);
    }

    /// @notice Strategy NAV (WETH-notional).
    function balance() public view override returns (uint256) {
        return strategy.balance();
    }

    /// @notice Share balance via liquid token.
    function balanceOf(address account) public view override returns (uint256) {
        return liquidToken.balanceOf(account);
    }

    /// @notice Share supply via liquid token.
    function totalSupply() public view override returns (uint256) {
        return liquidToken.totalSupply();
    }

    function depositETH() external payable override nonReentrant whenNotPaused returns (uint256 shares) {
        if (msg.value == 0) revert ZeroValue();
        weth.deposit{value: msg.value}();
        shares = _mintSharesAndDeploy(msg.value, true);
    }

    function depositWeth(uint256 amount) external override nonReentrant whenNotPaused returns (uint256 shares) {
        if (amount == 0) revert ZeroValue();
        IERC20(address(weth)).safeTransferFrom(msg.sender, address(this), amount);
        shares = _mintSharesAndDeploy(amount, true);
    }

    function depositAsset(uint256 amount) external override nonReentrant whenNotPaused returns (uint256 shares) {
        if (amount == 0) revert ZeroValue();
        if (!bootstrapped) revert NotBootstrapped();
        uint256 navBefore = balance();
        asset.safeTransferFrom(msg.sender, address(strategy), amount);
        strategy.ingestAndDeploy();
        uint256 credited = balance() > navBefore ? balance() - navBefore : 0;
        shares = _sharesForDeposit(credited, navBefore);
        if (shares == 0) revert ZeroValue();
        liquidToken.mint(msg.sender, shares);
        emit Deposit(msg.sender, credited, shares);
    }

    function _mintSharesAndDeploy(uint256 wethAmount, bool callDeposit) internal returns (uint256 shares) {
        if (!bootstrapped) revert NotBootstrapped();
        uint256 navBefore = balance();
        if (callDeposit) {
            IERC20(address(weth)).forceApprove(address(strategy), wethAmount);
            strategy.deposit(wethAmount);
        }
        // Mint from realized NAV credit (same as depositAsset) so shares match capital after rebalance costs.
        uint256 credited = balance() > navBefore ? balance() - navBefore : 0;
        shares = _sharesForDeposit(credited, navBefore);
        if (shares == 0) revert ZeroValue();
        liquidToken.mint(msg.sender, shares);
        emit Deposit(msg.sender, credited, shares);
    }

    function _sharesForDeposit(uint256 amount, uint256 navBefore) internal view returns (uint256) {
        uint256 supply = totalSupply();
        if (supply == 0 || navBefore == 0) return amount;
        return Math.mulDiv(amount, supply, navBefore);
    }

    function withdraw(uint256 shares, bool asAsset) external override nonReentrant whenNotPaused returns (uint256) {
        if (shares == 0) revert ZeroValue();
        if (totalSupply() == 0) revert ZeroValue();
        if (shares > balanceOf(msg.sender)) revert ZeroValue();

        IAutoStrategy.WithdrawToken out =
            asAsset ? IAutoStrategy.WithdrawToken.ASSET : IAutoStrategy.WithdrawToken.WETH;
        uint256 beforeBal = asAsset ? asset.balanceOf(msg.sender) : weth.balanceOf(msg.sender);
        // Strategy reads vault.totalSupply / balanceOf before burn so proportions stay correct.
        strategy.withdraw(shares, msg.sender, out);
        liquidToken.burn(msg.sender, shares);
        uint256 afterBal = asAsset ? asset.balanceOf(msg.sender) : weth.balanceOf(msg.sender);
        uint256 received = afterBal > beforeBal ? afterBal - beforeBal : 0;
        emit Withdraw(msg.sender, shares, asAsset, received);
        return received;
    }

    function enterNeutral() external override onlyOwner {
        strategy.enterNeutralFromVault();
        neutral = true;
        emit NeutralEntered(balance());
    }

    function resumeNormal() external override onlyOwner {
        strategy.resumeNormalFromVault();
        strategy.ingestAndDeploy();
        neutral = false;
        emit NeutralExited();
    }

    receive() external payable {
        revert("use depositETH");
    }
}
